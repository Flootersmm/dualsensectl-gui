# Dualsensectl GUI 
dualsensectl doesn't have a gui and i want to learn gtk and rust :) 

### Dependencies 
- dualsensectl (https://github.com/nowrep/dualsensectl)
- rust (rustup.rs)
- gtk4
- probably other stuff

### Usage 
To build:  
`cargo build --release`  
To run:  
`cargo run --release`
